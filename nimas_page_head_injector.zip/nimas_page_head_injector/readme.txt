Plugin name: PAGE HEAD INJECTOR
Plugin URI: nimasalehi.com/nimas-page-head-injector
Description: A plugin which enables the WordPress administrator to add CSS, JS, META tags to the <HEAD> section of pages.
Author: Nima Salehi
Author URI: http://www.nimasalehi.com
Version: 1.0
License: GNU General Public License v2

This simple plugin enables you to manully add section into your page head.
